from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'myfirstapp2/index.html')

def formulaire(request):
    return render(request, 'myfirstapp2/formulaire.html')

def bonjour(request):
    nom=request.GET["nom"]
    return render(request,'myfirstapp2/bonjour.html',{"nom":nom})

def main(request):
    return render(request, 'myfirstapp2/main.html')
